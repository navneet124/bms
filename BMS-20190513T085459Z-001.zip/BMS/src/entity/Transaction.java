package entity;

public class Transaction {
    private String transactionId;
    private String transactionDate;
    private String transactionMedium;
    private String fromAccountNumber;
    private String toAccountNumber;
    private double transactionAmount;
    private boolean transactionCommitted;
    private String fromAccountType;
    private String toAccountType;

    public Transaction() {

    }

    public String getFromAccountType() {
        return fromAccountType;
    }

    public void setFromAccountType(String fromAccountType) {
        this.fromAccountType = fromAccountType;
    }

    public String getToAccountType() {
        return toAccountType;
    }

    public void setToAccountType(String toAccountType) {
        this.toAccountType = toAccountType;
    }

    public double getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(double transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public boolean isTransactionCommitted() {
        return transactionCommitted;
    }

    public void setTransactionCommitted(boolean transactionCommitted) {
        this.transactionCommitted = transactionCommitted;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getTransactionMedium() {
        return transactionMedium;
    }

    public void setTransactionMedium(String transactionMedium) {
        this.transactionMedium = transactionMedium;
    }

    public String getFromAccountNumber() {
        return fromAccountNumber;
    }

    public void setFromAccountNumber(String fromAccountNumber) {
        this.fromAccountNumber = fromAccountNumber;
    }

    public String getToAccountNumber() {
        return toAccountNumber;
    }

    public void setToAccountNumber(String toAccountNumber) {
        this.toAccountNumber = toAccountNumber;
    }
}
