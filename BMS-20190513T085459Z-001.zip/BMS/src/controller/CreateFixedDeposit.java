package controller;

import entity.Customer;
import entity.FixedDeposit;
import entity.Transaction;
import service.CustomerService;

import service.FixedDepositService;
import service.SavingsAccountService;
import service.TransactionService;
import util.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateFixedDeposit {
    private JPanel rootPanel;
    private JButton createAccountButton;
    private JTextField customerId;
    private JButton searchCustomerButton;
    private JTextField customerName;
    private JTextField phoneNumber;
    private JRadioButton radioCash;
    private JRadioButton radioSavings;
    private JTextField initialDeposit;
    private JComboBox comboSavings;
    private JPanel fixedDeposit;
    private JSpinner duration;
    private JLabel lblAccountNumber;

    private CustomerService customerService = null;
    private SavingsAccountService savingsAccountService = null;
    private FixedDepositService fixedDepositService = null;
    private TransactionService transactionService = null;

    {
        customerService = new CustomerService();
        savingsAccountService = new SavingsAccountService();
        fixedDepositService = new FixedDepositService();
        transactionService = new TransactionService();

    }

    public CreateFixedDeposit() {
        searchCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String customerId = CreateFixedDeposit.this.customerId.getText().trim();
                if (customerIdValidate(customerId)) {
                    Customer customer = customerService.getCustomer(customerId);
                    if (customer == null) {
                        JFrame f = new JFrame();
                        JOptionPane.showMessageDialog(f, "Customer id not found. Please Create Customer First", "Alert", JOptionPane.WARNING_MESSAGE);
                    } else {
                        customerName.setText(customer.getFirstName() + " " + customer.getLastName());
                        phoneNumber.setText(customer.getPhoneNumber());
                        //createAccountButton.enable();
                        createAccountButton.setEnabled(true);
                        CreateFixedDeposit.this.customerId.setEditable(false);


                        //Add to the combo box
                        String arrAcc[] = savingsAccountService.getAccountNumberList(customerId);
                        for (String accNo : arrAcc) {
                            comboSavings.addItem(accNo);
                        }

                    }

                }
            }
        });


        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String initAmount = initialDeposit.getText().trim();


                int durationMonths = (int) duration.getValue();


                if (validate(initAmount, durationMonths)) {
                    FixedDeposit fixedDeposit = new FixedDeposit();

                    //toDO  : ERROR
                    fixedDeposit.setDurationInMonths(durationMonths);
                    Customer customer = new Customer();


                    customer.setCustomerId(CreateFixedDeposit.this.customerId.getText().trim());
                    fixedDeposit.setCustomer(customer);
                    fixedDeposit.setDepositBalance(Double.parseDouble(initAmount));


                    if (fixedDepositService.addAccount(fixedDeposit)) {
                        JFrame f = new JFrame();
                        JOptionPane.showMessageDialog(f, "Fixed Deposit Successfully Created ", "Alert", JOptionPane.WARNING_MESSAGE);

                        if(radioSavings.isEnabled()){
                           // String varName = (String)comboSavings.getSelectedItem();
                            String savingsAccountNumber = comboSavings.getSelectedItem().toString();
                            Transaction transaction = new Transaction();
                            transaction.setTransactionMedium(Constants.TRANSACTION_MEDIUM_TRANSFER);
                            transaction.setTransactionAmount(fixedDeposit.getDepositBalance());
                            transaction.setFromAccountNumber(savingsAccountNumber);
                            transaction.setToAccountNumber(fixedDeposit.getAccountNumber());
                            transaction.setFromAccountType(Constants.SAVINGS_ACCOUNT_TYPE);
                            transaction.setToAccountType(Constants.FIXED_DEPOSIT_TYPE);
                            transactionService.executeTransaction(transaction);

                        }
                        else{
                            // using cash to create FD
                        }


                        //TODO :: show the user details about the a/c and (add the a/c to the person's list somehow)

                    } else {
                        JFrame f = new JFrame();
                        JOptionPane.showMessageDialog(f, "Internal Error. Try Again", "Alert", JOptionPane.WARNING_MESSAGE);


                    }

                }
            }
        });

        radioCash.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                comboSavings.setEnabled(false);
                lblAccountNumber.setEnabled(false);

            }
        });
        radioSavings.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comboSavings.setEnabled(true);
                lblAccountNumber.setEnabled(true);
            }
        });
    }


    private boolean validate(String amtStr, int duration) {
        long amount = 0;
        if (amtStr.length() == 0) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Please provide Initial Amount", "Alert", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        try {
            amount = Long.parseLong(amtStr);
        } catch (NumberFormatException e) {

            System.out.println(e);
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Invalid Initial Amount", "Alert", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (amount < Constants.MINIMUM_ACCOUNT_BALANCE) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Minimum account balance is " + Constants.MINIMUM_ACCOUNT_BALANCE, "Alert", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (duration <= 0) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Invalid Duration", "Alert", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private boolean customerIdValidate(String customerId) {
        if (customerId.length() != 4) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Invalid Customer ID", "Alert", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {

            Integer.parseInt(customerId);
        } catch (NumberFormatException e) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Invalid Customer ID", "Alert", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    public void init() {
        JFrame frame = new JFrame("CreateFixedDeposit");
        frame.setContentPane(new CreateFixedDeposit().fixedDeposit);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        fixedDeposit = new JPanel();
        fixedDeposit.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        rootPanel = new JPanel();
        rootPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(9, 5, new Insets(0, 0, 0, 0), -1, -1));
        fixedDeposit.add(rootPanel, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label1 = new JLabel();
        label1.setText("Create Fixed Deposit");
        rootPanel.add(label1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 5, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        createAccountButton = new JButton();
        createAccountButton.setEnabled(false);
        createAccountButton.setText("Create Account");
        rootPanel.add(createAccountButton, new com.intellij.uiDesigner.core.GridConstraints(8, 1, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        customerId = new JTextField();
        customerId.setToolTipText("Enter Customer ID");
        rootPanel.add(customerId, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        final JLabel label2 = new JLabel();
        label2.setText("Customer Name :");
        rootPanel.add(label2, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        customerName = new JTextField();
        rootPanel.add(customerName, new com.intellij.uiDesigner.core.GridConstraints(3, 1, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        final JLabel label3 = new JLabel();
        label3.setText("Phone Number");
        rootPanel.add(label3, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 1, false));
        phoneNumber = new JTextField();
        rootPanel.add(phoneNumber, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        searchCustomerButton = new JButton();
        searchCustomerButton.setText("Search Customer");
        rootPanel.add(searchCustomerButton, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label4 = new JLabel();
        label4.setText("Select Customer :");
        rootPanel.add(label4, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 2, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label5 = new JLabel();
        label5.setText("Duration");
        rootPanel.add(label5, new com.intellij.uiDesigner.core.GridConstraints(7, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        duration = new JSpinner();
        rootPanel.add(duration, new com.intellij.uiDesigner.core.GridConstraints(7, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        radioSavings = new JRadioButton();
        radioSavings.setSelected(true);
        radioSavings.setText("Savings Transfer");
        rootPanel.add(radioSavings, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        radioCash = new JRadioButton();
        radioCash.setText("Cash ");
        rootPanel.add(radioCash, new com.intellij.uiDesigner.core.GridConstraints(6, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lblAccountNumber = new JLabel();
        lblAccountNumber.setText("Account Number :");
        rootPanel.add(lblAccountNumber, new com.intellij.uiDesigner.core.GridConstraints(5, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label6 = new JLabel();
        label6.setText("Initial Amount");
        rootPanel.add(label6, new com.intellij.uiDesigner.core.GridConstraints(6, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        initialDeposit = new JTextField();
        rootPanel.add(initialDeposit, new com.intellij.uiDesigner.core.GridConstraints(6, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        final JLabel label7 = new JLabel();
        label7.setText("INR");
        rootPanel.add(label7, new com.intellij.uiDesigner.core.GridConstraints(6, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        comboSavings = new JComboBox();
        rootPanel.add(comboSavings, new com.intellij.uiDesigner.core.GridConstraints(5, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label8 = new JLabel();
        label8.setText("months");
        rootPanel.add(label8, new com.intellij.uiDesigner.core.GridConstraints(7, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        ButtonGroup buttonGroup;
        buttonGroup = new ButtonGroup();
        buttonGroup.add(radioCash);
        buttonGroup.add(radioSavings);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return fixedDeposit;
    }
}
