package controller;

public class Main {
    public static void main(String[] args) {
/*
        CustomerRegistration customerRegistration = new CustomerRegistration();
        customerRegistration.init();
*/

/*        AdminLogin adminLogin=new AdminLogin();
        adminLogin.init();*/

/*        CreateSavingsAccount createSavingsAccount = new CreateSavingsAccount();
        createSavingsAccount.init();*/

        CreateFixedDeposit createFixedDeposit = new CreateFixedDeposit();
        createFixedDeposit.init();
    }

}
